<?php
    include_once("../inc/init.inc.php");
    include_once("../inc/functions.inc.php");

    // La page n'est accessible qu'aux admins qui sont connectés 
    if (!is_connected_and_is_admin()){
        header("location:" . URL . "/_index.php");
        exit();
    }

    // Objectif -> Afficher un tableau avec tout les membres

    // 1_ Faite la requete pour avoir tout les membres 
    // 2_ Dans le html, faite un tableau qui fais apparaitre les en-tête 
    // 3_ Dans le html, faite une boucle qui permet d'affichier tout les membres





    include_once("../inc/head.inc.php");
    include_once("../inc/header.inc.php");
    include_once("../inc/footer.inc.php");